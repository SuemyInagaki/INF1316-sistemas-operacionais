/*
Nomes: 
Tharik Lourenço 
Suemy Inagaki
Lab 7 - Gerenciamento de Memória
Sistemas Operacionais
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pagina.h"
#include "lfu.h"
int pageFaultsLFU = 0, pageSujaLFU = 0;


struct reg {
    Pagina* conteudo; 
    struct reg *prox;
};
typedef struct reg No;


//insere no fim
void inserePag (Pagina* x, No *le)
{
    No *p = le;
    No *nova;
    nova = malloc (sizeof (No));
    while (p->prox != NULL)
        p = p->prox;
    p->prox = nova;
    nova->conteudo = x;
    nova->conteudo->r = 0;
    nova->prox = NULL;
}

No* removeMenor(No* le, int menor){
    
    No* ant = NULL;
    No* aux = le;
    while(aux != NULL)
    {
        if(aux->conteudo->r == menor)
            break;
        ant = aux;
        aux = aux->prox;
    }

    if(ant == NULL){
        le = le->prox;
    }
    else if(aux != NULL){
        ant = aux->prox;
    }
    return le;
}


No* LFU(Pagina* p, No* le){
    int menor = le->conteudo->r;
    //acha o menor r
    for(No* i = le; i != NULL; i = i->prox){
        if(i->conteudo->r < menor){ //se o r for menor que o menor
            menor = i->conteudo->r;
        }
    }
    le = removeMenor(le, menor);
    inserePag(p, le);
    return le;
}


void typeLfu(char *filePath, int numPages, int auxShift,int pageSize,int memSize){
    unsigned int endrCod;
    char rw;
    FILE *arq;
    
    arq = fopen(filePath,"r");
    if (arq == NULL){
        printf("Problemas na criacao do arquivo\n");
        exit(-1);
    }
    No * heap = (No *)malloc(sizeof(No));   
    heap->conteudo = NULL;
    heap->prox = NULL;
    No * auxHeap;
    while((fscanf(arq,"%x %c\n", &endrCod, &rw))!=EOF){
        auxHeap = heap;
        Pagina* auxPagina = (Pagina *)malloc(sizeof(Pagina));
        auxPagina->endrCod = endrCod>> auxShift;
        if(rw == 'W') {
            auxPagina->m = 1;
            pageSujaLFU++;
        }
        else
            auxPagina->m = 0;

        for(int i=0;i<numPages;i++ ){
            if (heap->conteudo == NULL){
                heap->conteudo = auxPagina;
                break;
            }
            heap->conteudo->timer ++;
            if(auxHeap->conteudo->endrCod == auxPagina->endrCod){
                //ja existe
                auxHeap->conteudo->timer=0; 
                auxHeap->conteudo->r++;
                break;
            }
            else if (auxHeap->prox == NULL && i < numPages-1){
                //nao existe
                //fila nao cheia
                auxPagina->r++;
                inserePag(auxPagina, heap);
                break;
            }
            else if (i == numPages-1){
                //pagina nao existe
                //tabela cheia -> lfu
                pageFaultsLFU++;
                heap = LFU(auxPagina, heap);
                auxHeap = heap;
                break;
            }
            auxHeap = auxHeap->prox;
        }     
    }
    printf("Arquivo de entrada: %s\n", filePath);
    printf("Tamanho da memoria fisica: %d MB\n", memSize);
    printf("Tamanho das páginas: %d KB\n", pageSize);
    printf("Algoritmo de substituiçao: LFU\n");
    printf("Numero de Faltas de Paginas: %d\n", pageFaultsLFU);
    printf("Numero de Paginas Escritas: %d\n", pageSujaLFU);
}