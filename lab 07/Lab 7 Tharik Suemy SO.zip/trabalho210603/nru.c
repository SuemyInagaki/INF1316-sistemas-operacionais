/*
Nomes: 
Tharik Lourenço 
Suemy Inagaki
Lab 7 - Gerenciamento de Memória
Sistemas Operacionais
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pagina.h"
#include "nru.h"
int pageFaultsNRU = 0, pageSujaNRU = 0;

Pagina ** NRU(Pagina ** allPags, int numPages, char rw, unsigned int endrCod, int auxShift) {
    int i;
    //escolhendo qual pagina trocar
    for(i = 0; i < numPages; i++){
        //NAO referenciada e NAO modificada
        // (R=0 , M=0)
        if(allPags[i]->r == 0 && allPags[i]->m == 0){
            break;
        }
        //NAO referenciada e modificada
        // (R=0 , M=1)
        else if(allPags[i]->r == 0 && allPags[i]->m > 0){
            pageSujaNRU++;
            break;
        }
        //referenciada e NAO modificada
        // (R=1 , M=0)
        else if(allPags[i]->r > 0 && allPags[i]->m == 0){
            break;
        }
        //referenciada e modificada
        // (R=1 , M=1)
        else if(allPags[i]->r > 0 && allPags[i]->m > 0){
            pageSujaNRU++;
            break;
        }
    }

    //trocando a pagina
    allPags[i]->endrCod = endrCod >> auxShift;
    allPags[i]->r = 1;
    allPags[i]->timer = 0;
    if(rw == 'W') 
        allPags[i]->m = 1;
    else
        allPags[i]->m = 0;
    
    return allPags;
}

void typeNru(char *filePath, int numPages, int auxShift,int pageSize,int memSize){
    
    unsigned int endrCod;
    char rw;
    FILE *arq;
    arq = fopen(filePath,"r");
    if (arq == NULL){
        printf("Problemas na criacao do arquivo\n");
        exit(-1);
    }

    Pagina **allPags = (Pagina**)malloc(numPages*sizeof(Pagina*)); // Aloca a matriz de todas as paginas
    if(allPags == NULL){
        printf("Erro ao alocar memoria para tabela de páginas.\n");
        exit(-1);
    }

    for(int i = 0; i < numPages; i++) {
        allPags[i] = (Pagina*) malloc (sizeof(Pagina)); // Aloca as paginas na matriz
        if(allPags[i] == NULL) {
            printf("Erro ao tentar alocar memória para página %d.\n", i);
            exit(-1);
        }
        allPags[i]->timer = 0;
        allPags[i]->endrCod = 0;
    }

    while((fscanf(arq,"%x %c\n", &endrCod, &rw))!=EOF){
        for(int i=0;i<numPages;i++){
            allPags[i]->timer ++;
            if (allPags[i]->endrCod  == endrCod >> auxShift){
                allPags[i]->timer = 0;
                allPags[i]->r ++;
                if(rw == 'W'){
                    allPags[i]->m = 1;
                    pageSujaNRU++;
                }   
                else
                    allPags[i]->m = 0;
                break;
            }
            else if (allPags[i]->endrCod == 0 && i < numPages - 1){
                //Pagina ainda nao exsite e memoria nao cheia
                allPags[i] -> endrCod = endrCod >> auxShift;
                allPags[i]->r++;
                if(rw == 'W'){
                    allPags[i]->m = 1;
                    pageSujaNRU++;
                } 
                else
                    allPags[i]->m = 0;
                break;
            }

            if (i == numPages-1){
                //pagina nao existe na tabela
                //tabela cheia
                pageFaultsNRU++;
                allPags = NRU(allPags, numPages, rw, endrCod,auxShift);
                break;
            }
        }
    }

    printf("Arquivo de entrada: %s\n", filePath);
    printf("Tamanho da memoria fisica: %d MB\n", memSize);
    printf("Tamanho das páginas: %d KB\n", pageSize);
    printf("Algoritmo de substituiçao: NRU\n");
    printf("Numero de Faltas de Paginas: %d\n", pageFaultsNRU);
    printf("Numero de Paginas Escritas: %d\n", pageSujaNRU);

}