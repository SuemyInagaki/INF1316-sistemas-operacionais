
void typeNru(char *filePath, int numPages, int auxShift,int pageSize,int memSize);
