typedef struct pagina {
    int r; // status referenciada
    int m; // status modificada
    unsigned int endrCod; // endereco da pagina
    int timer; // contador de passagem 
} Pagina;