#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pagina.h"
#include "fifo2.h"
#include "lfu.h"
int pageFaultsFIFO = 0, pageSujaFIFO = 0;


struct reg {
    Pagina* conteudo; 
    struct reg *prox;
};
typedef struct reg No;

void imprime (No *le) {
   No *p;
   for (p = le; p != NULL; p = p->prox)
      printf ("%d -", p->conteudo->endrCod);
    printf("\n");
}
void insere (Pagina* x, No *le)
{
    No *p = le;
    No *nova;
    nova = malloc (sizeof (No));
    while (p->prox != NULL)
        p = p->prox;
    p->prox = nova;
    nova->conteudo = x;
    nova->conteudo->r = 0;
    nova->prox = NULL;
}

No* removeCelula (No *p)
{
    No *lixo;
    lixo = p;
    p = lixo->prox;
    free (lixo);
    return p;
}

No* arruma(No* le){
    //tira o primeiro elemento e coloca no final
    Pagina* aux = le->conteudo;
    No *lixo = le;
    insere(aux,le);
    le = lixo->prox;
    return le;
}

No* Fifo2(Pagina* p, No* le){
    while (le->conteudo->r > 0)
    {
        le = arruma(le);
    }

    le = removeCelula(le);
    insere(p, le);    
    return le;
}


void typeFifo2(char *filePath, int numPages, int auxShift,int pageSize,int memSize){
    unsigned int endrCod;
    char rw;
    FILE *arq;
    
    arq = fopen(filePath,"r");
    if (arq == NULL){
        printf("Problemas na criacao do arquivo\n");
        exit(-1);
    }
    No * heap = (No *)malloc(sizeof(No));   
    heap->conteudo = NULL;
    heap->prox = NULL;
    No * auxHeap;
    while((fscanf(arq,"%x %c\n", &endrCod, &rw))!=EOF){
        auxHeap = heap;
        Pagina* auxPagina = (Pagina *)malloc(sizeof(Pagina));
        auxPagina->endrCod = endrCod>> auxShift;
        if(rw == 'W') {
            pageSujaFIFO++;
            auxPagina->m = 1;
            }
        else
            auxPagina->m = 0;

        for(int i=0;i<numPages;i++ ){
            if (heap->conteudo == NULL){
                heap->conteudo = auxPagina;
                break;
            }
            heap->conteudo->timer ++;
            if(auxHeap->conteudo->endrCod == auxPagina->endrCod){
                //ja existe

                auxHeap->conteudo->timer=0; 
                auxHeap->conteudo->r++;
                
                break;
            }
            else if (auxHeap->prox == NULL){
                //nao existe
                //fila nao cheia
                auxPagina->r++;
                insere(auxPagina, heap);
                break;
            }
            else if (i == numPages-1){
                //pagina nao existe
                //tabela cheia -> fifo2 chance
                pageFaultsFIFO++;
                heap = Fifo2(auxPagina, heap);
                auxHeap = heap;
                break;
            }
            auxHeap = auxHeap->prox;
        }
            
    }
    
    printf("Arquivo de entrada: %s\n", filePath);
    printf("Tamanho da memoria fisica: %d MB\n", memSize);
    printf("Tamanho das páginas: %d KB\n", pageSize);
    printf("Algoritmo de substituiçao: FIFO2\n");
    printf("Numero de Faltas de Paginas: %d\n", pageFaultsFIFO);
    printf("Numero de Paginas Escritas: %d\n", pageSujaFIFO);

}

