/*
Nomes: 
Tharik Lourenço 
Suemy Inagaki
Lab 7 - Gerenciamento de Memória
Sistemas Operacionais
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "fifo2.h"
#include "nru.h"
#include "pagina.h"
#include "lfu.h"



int calculaShift(int size) {
    switch (size){
        case 8:
            return 13;
        case 16:
            return 14;
        case 32:
            return 15;
    }
    return 0;
}




int main (int argc, char *argv[]){
    int numPages,auxShift;
    
   
    int memSize = atoi(argv[4]);
    int pageSize = atoi(argv[3]); 
    char *filePath = argv[2];
    char *algoritmo = argv[1];
    if(memSize < 1 || memSize > 16){
        printf("ERRO: Tamanho da memoria deve estar entre 1 e 16.\n");
        exit(-1);
    }
    if(pageSize < 8 || pageSize > 32){
        printf("ERRO: Tamanho da pagina deve estar entre 8 e 32.\n");
        exit(-1);
    }
    if(strcmp(algoritmo, "LFU") && strcmp(algoritmo, "NRU") && strcmp(algoritmo,"FIFO2")){
        printf("ERRO: tipo de Algoritmo invalido.\n");
        exit(-1);
    }
    printf ("Executando o simulador...\n");
    numPages = (memSize*1024)/pageSize;
    auxShift = calculaShift(pageSize);
    
    /*----------qual tipo e chamar o tipo--------------*/
    double begin = clock();
    if(strcmp(algoritmo, "NRU") == 0){
        typeNru(filePath, numPages, auxShift, pageSize, memSize);
    }
    else if(strcmp(algoritmo, "FIFO2") == 0){
        typeFifo2(filePath, numPages, auxShift, pageSize, memSize);
    }
    else if(strcmp(algoritmo, "LFU") == 0){
        typeLfu(filePath, numPages, auxShift, pageSize, memSize);
    }
    double end = clock();
    printf("Tempo de execução = %f\n", (double)(end-begin)/CLOCKS_PER_SEC);
    return 0;
}
