
void typeFifo2(char *filePath, int numPages, int auxShift,int pageSize,int memSize);