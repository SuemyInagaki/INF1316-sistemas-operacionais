/*
Tharik Lourenço
Suemy Inagaki
Lab 03 Threads, questão 1
Entrega Final
Sistemas Operacionais
*/


#include <pthread.h>
#include <stdio.h>
#include<unistd.h>
#define NUM_THREADS 2

int count = 0;

void *contCrescente(void* threadid){
    int c = 0;
    for(int i=1;i<=60;i++){
        sleep(2);
        c+=5;
        printf("Thread 0:%d\n",c);
    }
    pthread_exit(NULL);
}

void *contDecrescente(void* threadid){
	int d = 300;
    for(int j= 1;j<=60;j++){
        sleep(1);
        d-=5;
        printf("Thread 1:%d\n",d);
	}
    pthread_exit(NULL);
}

void *incrementa(void* threadid){
    for(int i=1;i<=2000;i++){
        sleep(0.1);
        count+=5;
        printf("Thread 0:%d\n",count);
	}
    pthread_exit(NULL);
}
void *decrementa(void* threadid){
     for(int j= 1;j<=2000;j++){
        sleep(0.1);
        count-=5;
        printf("Thread 1:%d\n",count);
	}
    pthread_exit(NULL);
}


int main()
{
	pthread_t threads[NUM_THREADS];
	int t;
	/*Verificando concorrencia*/
	printf("Creating thread 0\n");
	pthread_create(&threads[0], NULL, contCrescente, (void *)0);
	printf("Creating thread 1\n");
	pthread_create(&threads[1], NULL, contDecrescente, (void *)1);
	for(t=0; t < NUM_THREADS; t++)
		pthread_join(threads[t],NULL); 

	/*Manipulando variavel global*/
	printf("Creating thread 0\n");
	pthread_create(&threads[0], NULL, incrementa, (void *)0);
	printf("Creating thread 1\n");
	pthread_create(&threads[1], NULL, decrementa, (void *)1);
	for(t=0; t < NUM_THREADS; t++)
		pthread_join(threads[t],NULL); 
	printf("Variavel global: %d\n", count);
}