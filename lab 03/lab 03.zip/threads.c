/*
Tharik Lourenço
Suemy Inagaki
Lab 03 Threads, questao 2
Entrega Final
Sistemas Operacionais
*/


#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>

#define NUM_THREADS 4
#define TAM_TOTAL 4000

int count = 0;
int max = -1;

int p[TAM_TOTAL];

void* percorre(void* threadid){
	int ini, fim;
    if(threadid == 0){
        ini = 0;
        fim = 1000;
	}
    else if(threadid == 1){
        ini = 1000;
        fim = 2000;
    }
    else if(threadid == 2){
        ini = 2000;
        fim = 3000;
    }
    else{
        ini = 3000;
        fim = 4000;
    }
    for(int i=ini;i<fim;i++){
        sleep(0.1);
        if(p[i] > max)
            max = p[i];
        printf("Processo %d:p[%d]=%3d\n", threadid, i,p[i]);
    }
    pthread_exit(NULL);
}


int main()
{

    clock_t begin = clock();

	pthread_t threads[NUM_THREADS];
	int t;
    /*
     Preenche vetor com numeros entre 0 e 999
     Coloca o valor 4000 na posicao 200
     O programa deve retornar max = 4000
    */

	for(int t=0;t<TAM_TOTAL;t++){
        p[t]= rand()%1000;
        if(t == 200)
        	p[t] = 4000;
    }

	printf("Creating thread 0\n");
    pthread_create(&threads[0], NULL, percorre, (void *)0);
    printf("Creating thread 1\n");
	pthread_create(&threads[1], NULL, percorre, (void *)1);
	printf("Creating thread 2\n");
    pthread_create(&threads[2], NULL, percorre, (void *)2);
    printf("Creating thread 3\n");
    pthread_create(&threads[3], NULL, percorre, (void *)3);

	for(t=0; t < NUM_THREADS; t++)
		pthread_join(threads[t],NULL); 

	printf("max = %d\n", max);

    clock_t end = clock();
    double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
    printf("Tempo gasto na execucao: %.4fms\n", time_spent*1000);
}